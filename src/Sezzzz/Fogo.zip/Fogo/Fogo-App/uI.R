#### General setttings #########################################################
library(shiny)


#### Initialize shiny user interface ###########################################
shinyUI(fluidPage(
  
  titlePanel("Fogo"),
  
  sidebarLayout(
    sidebarPanel(
      
        selectInput("Vek", label = "Vektordaten:",
                    choices = c("ID","ELEV","COVRG","NAT","AGR","ANIMALS"), selected = "NAT"),
        
        selectInput("col", label = "Fogo-Farbe:",
                    choices = c("gray","terrain","sea-land"), selected = "sea-land"),
        
        sliderInput("grid", label = "Chooce Grid_lines",
                    min = 3, max = 10, value = 5, step = 1)
    
    ),
    mainPanel(plotOutput("Fogo")
    )
  )
)
)