#### General setttings #########################################################

packages <- c(library("raster"),
              library("rgdal"),
              library("lattice"),
              library("latticeExtra"),
              library("RColorBrewer"),
              library("latticeExtra"),
              library("data.table"))
lapply(packages, library, character.only = TRUE)


#### Load necessary datasets ###################################################

raster <- "LC82100502014328LGN00_B3.tif"
vector <- "data_2014_subset1.shp"

vectorin <- readOGR(vector, layer = "data_2014_subset1")
rasterin <- raster(raster)







#### Initialize shiny server ###################################################
shinyServer(function(input, output) {
  colorvector = "Greens"
  
  
  
  
  breaks <- quantile(rasterin, seq(0.0, 1.0, length.out = 256))
  
  yat = seq(extent(rasterin)@ymin, 
            extent(rasterin)@ymax, length.out = 5)
  xat = seq(extent(rasterin)@xmin, 
            extent(rasterin)@xmax, length.out = 5)
  
  
  
  
  vector_utm <- spTransform(vectorin, CRS(projection(rasterin)))
  colnames(vector_utm@data)
  vector_colors <- colorRampPalette(brewer.pal(5,colorvector))(5)
  
  
  
  output$Fogo <- renderPlot({
    
    if(input$col ==   "gray") {color.sheme = gray.colors(256)} else {if(input$col == "terrain"){color.sheme = terrain.colors(256)} else {color.sheme = topo.colors(256)}}
    ?RColorBrewer
    
    x<-attr(vector_utm,"data")
    y<-x[input$Vek]
    a<-y[,input$Vek]
    
    vector_classes <- cut(a, seq(min(y,na.rm=TRUE),max(y,na.rm=TRUE), by = (max(y,na.rm=TRUE)-min(y,na.rm=TRUE))/5))
    
    yat = seq(extent(rasterin)@ymin, 
              extent(rasterin)@ymax, length.out = input$grid)
    xat = seq(extent(rasterin)@xmin, 
              extent(rasterin)@xmax, length.out = input$grid)
    
    
    plt <- spplot(rasterin, col.regions = color.sheme, at = breaks,
                  key = list(space = 'left', text = list(levels(vector_classes)), 
                             points = list(pch = 21, cex = 2, fill = vector_colors)),
                  colorkey=list(space="right"),
                  panel = function(...){
                    panel.levelplot(...)
                    panel.abline(h = yat, v = xat, col = "grey0", lwd = 0.8, lty = 3) 
                  },
                  scales = list(x = list(at = xat),
                                y = list(at = yat)))
    
    orl <- spplot(vector_utm, zcol = input$Vek, col.regions = vector_colors, 
                  cuts = seq(min(y,na.rm=T),max(y,na.rm=T), 
                             by = max(y/5,na.rm=T)))
    
    
    
    plt + as.layer(orl)
  })
})